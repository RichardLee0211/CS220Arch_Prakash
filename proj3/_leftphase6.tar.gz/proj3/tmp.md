wli100
19 29 4 17 0 42
0 or 8 or 16 ... multipies of 8
6 5
166
7 3 -1 0 0 0 0 0
