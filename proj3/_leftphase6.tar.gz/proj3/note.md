# this is note file
9c3313693bcbdb70ba295b0e660872fe  ./bomb2.0
tools: tmux, gdb, vim, objdump
highly unlike that string is hard coded in the C code,
so it can't be in the text area, or in the stack
but before comparing, string must be store some where in the heap

# answer
the phase the userName of linux system
